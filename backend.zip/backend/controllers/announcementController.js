const Announcement = require('../models/Announcement');

// Create a new announcement
exports.createAnnouncement = async (req, res) => {
  try {
    const { title, quantity, price, location, type, imageUrl } = req.body;

    // Validation améliorée
    if (!title || !quantity || !price || !location || !type || !imageUrl) {
      return res.status(400).json({
        success: false,
        message: 'Missing required fields',
        details: {
          title: !title ? 'Title is required' : null,
          quantity: !quantity ? 'Quantity is required' : null,
          price: !price ? 'Price is required' : null,
          location: !location ? 'Location is required' : null,
          type: !type ? 'Type is required' : null,
          imageUrl: !imageUrl ? 'Image URL is required' : null,
        }
      });
    }

    // Validation de l'URL de l'image
    try {
      new URL(imageUrl);
    } catch (e) {
      return res.status(400).json({
        success: false,
        message: 'Invalid image URL format',
      });
    }

    // Validation des types
    if (typeof price !== 'number' || price <= 0) {
      return res.status(400).json({
        success: false,
        message: 'Invalid price value',
      });
    }

    if (typeof quantity !== 'number' || quantity <= 0) {
      return res.status(400).json({
        success: false,
        message: 'Invalid quantity value',
      });
    }

    // Create and save the announcement
    const newAnnouncement = new Announcement({
      title,
      quantity,
      price,
      location,
      type,
      imageUrl,
      createdAt: new Date(),
    });

    await newAnnouncement.save();

    res.status(201).json({
      success: true,
      message: 'Announcement created successfully!',
      data: newAnnouncement,
    });
  } catch (error) {
    console.error('Error creating announcement:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while creating announcement',
      error: error.message,
    });
  }
};

// Get all announcements
exports.getAnnouncements = async (req, res) => {
  try {
    const announcements = await Announcement.find();
    res.status(200).json(announcements);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Delete announcement
exports.deleteAnnouncement = async (req, res) => {
  try {
    const { id } = req.params;
    const deletedAnnouncement = await Announcement.findByIdAndDelete(id);
    
    if (!deletedAnnouncement) {
      return res.status(404).json({ message: 'Announcement not found' });
    }
    
    res.status(200).json({ message: 'Announcement deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Update announcement
exports.updateAnnouncement = async (req, res) => {
  try {
    const { id } = req.params;
    const updatedAnnouncement = await Announcement.findByIdAndUpdate(
      id,
      req.body,
      { new: true }
    );
    
    if (!updatedAnnouncement) {
      return res.status(404).json({ message: 'Announcement not found' });
    }
    
    res.status(200).json(updatedAnnouncement);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
