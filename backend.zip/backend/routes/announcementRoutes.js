const express = require('express');
const router = express.Router();
const {
  createAnnouncement,
  getAnnouncements,
  deleteAnnouncement,
  updateAnnouncement
} = require('../controllers/announcementController');

// Routes
router.post('/announcements', createAnnouncement);
router.get('/announcements', getAnnouncements);
router.delete('/announcements/:id', deleteAnnouncement);
router.put('/announcements/:id', updateAnnouncement);

module.exports = router;
