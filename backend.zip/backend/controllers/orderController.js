const Order = require('../models/Order');
const Announcement = require('../models/Announcement');

// Créer une nouvelle commande
exports.createOrder = async (req, res) => {
  try {
    console.log('Received order request:', req.body); // Log pour déboguer

    const {
      items,
      deliveryAddress,
      paymentMethod,
    } = req.body;

    // Validation des données requises
    if (!items || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Items array is required and cannot be empty'
      });
    }

    if (!deliveryAddress) {
      return res.status(400).json({
        success: false,
        message: 'Delivery address is required'
      });
    }

    if (!paymentMethod) {
      return res.status(400).json({
        success: false,
        message: 'Payment method is required'
      });
    }

    // Calculer le montant total
    let totalAmount = 0;
    const validatedItems = [];

    for (const item of items) {
      console.log('Processing item:', item); // Log pour déboguer

      if (!item.announcementId || !item.quantity) {
        return res.status(400).json({
          success: false,
          message: 'Each item must have announcementId and quantity'
        });
      }

      const announcement = await Announcement.findById(item.announcementId);
      if (!announcement) {
        return res.status(404).json({
          success: false,
          message: `Announcement ${item.announcementId} not found`
        });
      }

      const itemTotal = announcement.price * item.quantity;
      totalAmount += itemTotal;

      validatedItems.push({
        announcementId: item.announcementId,
        quantity: item.quantity,
        price: announcement.price
      });
    }

    console.log('Creating order with total amount:', totalAmount); // Log pour déboguer

    const order = new Order({
      userId: req.user._id,
      items: validatedItems,
      totalAmount,
      deliveryAddress,
      paymentMethod,
      paymentStatus: 'pending',
      orderStatus: 'placed'
    });

    console.log('Order object before save:', order); // Log pour déboguer

    const savedOrder = await order.save();
    console.log('Order saved successfully:', savedOrder); // Log pour déboguer

    res.status(201).json({
      success: true,
      message: 'Order created successfully',
      data: savedOrder
    });

  } catch (error) {
    console.error('Error in createOrder:', error); // Log pour déboguer
    res.status(500).json({
      success: false,
      message: 'Error creating order',
      error: error.message
    });
  }
};

// Obtenir toutes les commandes d'un utilisateur
exports.getUserOrders = async (req, res) => {
  try {
    const orders = await Order.find({ userId: req.user._id })
      .populate('items.announcementId')
      .sort('-createdAt');

    res.status(200).json({
      success: true,
      data: orders
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching orders',
      error: error.message
    });
  }
};

// Obtenir une commande spécifique
exports.getOrder = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id)
      .populate('items.announcementId');

    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Order not found'
      });
    }

    res.status(200).json({
      success: true,
      data: order
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching order',
      error: error.message
    });
  }
};

// Mettre à jour le statut de la commande
exports.updateOrderStatus = async (req, res) => {
  try {
    const { orderStatus } = req.body;
    const order = await Order.findByIdAndUpdate(
      req.params.id,
      { 
        orderStatus,
        updatedAt: Date.now()
      },
      { new: true }
    );

    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Order not found'
      });
    }

    res.status(200).json({
      success: true,
      data: order
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error updating order status',
      error: error.message
    });
  }
};

// Mettre à jour le statut du paiement
exports.updatePaymentStatus = async (req, res) => {
  try {
    const { paymentStatus, paymentDetails } = req.body;
    const order = await Order.findByIdAndUpdate(
      req.params.id,
      {
        paymentStatus,
        paymentDetails,
        updatedAt: Date.now()
      },
      { new: true }
    );

    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Order not found'
      });
    }

    res.status(200).json({
      success: true,
      data: order
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error updating payment status',
      error: error.message
    });
  }
};
